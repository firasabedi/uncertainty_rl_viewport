function s = build_state(lms, p_hat, C_n, state_type, cfg)
% BUILD_STATE  Construct the MDP state vector s_n (Section 4.4 of paper).
%
%   s = build_state(lms, p_hat, C_n, state_type, cfg)
%
%   State vector (L2-based, Eq. 7 in paper):
%     s_n = [D_{t-H+1}, ..., D_{t}, D_hat_{t+1}, sigma^2_n, C_n]
%
%     D_{t-k}    = ||P_{t-k} - P_{t-k-1}||  (displacement magnitude)
%     D_hat_{t+1}= predicted next displacement magnitude
%     sigma^2_n  = variance proxy (Eq. 6)
%     C_n        = empirical offloading rate up to epoch n
%
%   Inputs:
%     lms        - current LMS predictor struct
%     p_hat      - [1 x 3] predicted next position
%     C_n        - scalar, current offloading rate
%     state_type - 'L2' | 'Pos'
%     cfg        - configuration struct
%
%   Output:
%     s - [state_dim x 1] state vector
% -------------------------------------------------------------------------

H = cfg.H;

if strcmp(state_type, 'L2')
    %% L2-displacement based state (used in paper, dimension = H+3)
    % Displacement magnitudes of the history buffer
    buf = double(lms.buffer);   % [H x 3]
    D   = zeros(H, 1);
    for k = 2:H
        D(k) = norm(buf(k,:) - buf(k-1,:));
    end
    D(1) = D(2);   % replicate for first entry (no prior)

    % Predicted next displacement
    if lms.step > 1
        D_hat = norm(p_hat - buf(end,:));
    else
        D_hat = 0;
    end

    % Variance proxy (Eq. 6)
    sigma2 = compute_variance_proxy(lms);

    s = [D; D_hat; sigma2; C_n];

else   % 'Pos' — raw positional state
    %% Raw positional state (dimension = H*3 + 1 + 1)
    buf    = double(lms.buffer);   % [H x 3]
    sigma2 = compute_variance_proxy(lms);
    s      = [buf(:); sigma2; C_n];
end
end


function [R, constraint_violation] = compute_reward(p_true, p_hat_final, C_n, cfg)
% COMPUTE_REWARD  Penalty-augmented reward function (Eq. 8 in paper).
%
%   R = -||P_{n,t+1} - P_hat_{n,t+1}||^2 - lambda * phi(C_n - zeta)
%
%   phi(x) = max(0, x)^2  if x > 0   (Eq. 9)
%            0             otherwise
%
%   Inputs:
%     p_true      - [1 x 3] true next head position
%     p_hat_final - [1 x 3] adopted prediction (local or server)
%     C_n         - current empirical offloading rate
%     cfg         - configuration struct (uses cfg.zeta, cfg.lambda)
%
%   Outputs:
%     R                    - scalar reward
%     constraint_violation - scalar phi(C_n - zeta) [for monitoring]
% -------------------------------------------------------------------------

% Prediction error term
pred_error = sum((p_true - p_hat_final).^2);   % MSE (Eq. 1)

% Constraint penalty (Eq. 9)
excess = C_n - cfg.zeta;
if excess > 0
    constraint_violation = max(0, excess)^2;
else
    constraint_violation = 0;
end

R = -pred_error - cfg.lambda * constraint_violation;
end


function C_n = update_offloading_rate(C_n, a_n, n)
% UPDATE_OFFLOADING_RATE  Running mean of offloading decisions.
%
%   C_n = update_offloading_rate(C_n, a_n, n)
%
%   C_n = (1/n) * sum_{k=1}^{n} I_k   (running mean)
% -------------------------------------------------------------------------

C_n = ((n-1) * C_n + double(a_n)) / n;
end
