function buf = replay_buffer_init(capacity, state_dim)
% REPLAY_BUFFER_INIT  Initialise a circular experience replay buffer.
%
%   buf = replay_buffer_init(capacity, state_dim)
%
%   Inputs:
%     capacity  - maximum number of transitions stored
%     state_dim - dimension of state vector
%
%   Output:
%     buf struct with pre-allocated arrays for O(1) insertion.
% -------------------------------------------------------------------------

buf.capacity  = capacity;
buf.state_dim = state_dim;
buf.states    = zeros(capacity, state_dim, 'single');
buf.actions   = zeros(capacity, 1,         'uint8');
buf.rewards   = zeros(capacity, 1,         'single');
buf.next_states = zeros(capacity, state_dim, 'single');
buf.dones     = false(capacity, 1);
buf.ptr       = 1;        % next write position
buf.size      = 0;        % current number of valid entries
end


function buf = replay_buffer_add(buf, s, a, r, s_next, done)
% REPLAY_BUFFER_ADD  Insert one transition into the replay buffer.
%
%   buf = replay_buffer_add(buf, s, a, r, s_next, done)
% -------------------------------------------------------------------------

idx = buf.ptr;
buf.states(idx,:)      = single(s(:)');
buf.actions(idx)       = uint8(a);
buf.rewards(idx)       = single(r);
buf.next_states(idx,:) = single(s_next(:)');
buf.dones(idx)         = done;

buf.ptr  = mod(buf.ptr, buf.capacity) + 1;
buf.size = min(buf.size + 1, buf.capacity);
end


function [s, a, r, s_next, done] = replay_buffer_sample(buf, batch_size)
% REPLAY_BUFFER_SAMPLE  Sample a random mini-batch from the buffer.
%
%   [s, a, r, s_next, done] = replay_buffer_sample(buf, batch_size)
%
%   Returns:
%     s      - [batch_size x state_dim]  current states
%     a      - [batch_size x 1]          actions (0 or 1)
%     r      - [batch_size x 1]          rewards
%     s_next - [batch_size x state_dim]  next states
%     done   - [batch_size x 1] logical  episode-end flags
% -------------------------------------------------------------------------

idx    = randperm(buf.size, min(batch_size, buf.size));
s      = double(buf.states(idx, :));
a      = double(buf.actions(idx));
r      = double(buf.rewards(idx));
s_next = double(buf.next_states(idx, :));
done   = buf.dones(idx);
end
