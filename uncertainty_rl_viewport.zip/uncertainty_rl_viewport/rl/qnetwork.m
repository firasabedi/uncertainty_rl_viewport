function net = qnetwork_init(state_dim, n_actions, n_hidden, hidden_units, arch_type)
% QNETWORK_INIT  Initialise a Q-network with Xavier weight initialisation.
%
%   net = qnetwork_init(state_dim, n_actions, n_hidden, hidden_units, arch_type)
%
%   Inputs:
%     state_dim    - input dimension (H+3 for L2 state)
%     n_actions    - output dimension (2: local or offload)
%     n_hidden     - number of hidden layers (3 in paper)
%     hidden_units - units per hidden layer (128 in paper)
%     arch_type    - 'DQN' | 'DuelingDQN'
%
%   The network is represented as a struct with weight matrices and biases.
%   This pure-MATLAB implementation avoids Deep Learning Toolbox dependency.
%
%   Network architecture (DQN):
%     Input (state_dim) -> FC(128) -> ReLU -> FC(128) -> ReLU
%                       -> FC(128) -> ReLU -> FC(n_actions)
%
%   Network architecture (Dueling DQN, Eq. 10 in paper):
%     Shared trunk: Input -> FC(128) -> ReLU -> FC(128) -> ReLU
%     Value stream:     FC(128) -> ReLU -> FC(1)
%     Advantage stream: FC(128) -> ReLU -> FC(n_actions)
%     Q = V + A - mean(A)
% -------------------------------------------------------------------------

net.arch_type   = arch_type;
net.state_dim   = state_dim;
net.n_actions   = n_actions;
net.n_hidden    = n_hidden;
net.hidden_units = hidden_units;

%% ---- Xavier initialisation -----------------------------------------
scale = @(fan_in, fan_out) sqrt(2.0 / (fan_in + fan_out));

if strcmp(arch_type, 'DQN')
    % Shared layers
    dims = [state_dim, repmat(hidden_units, 1, n_hidden), n_actions];
    net.W = cell(n_hidden+1, 1);
    net.b = cell(n_hidden+1, 1);
    for k = 1:n_hidden+1
        s = scale(dims(k), dims(k+1));
        net.W{k} = s * randn(dims(k+1), dims(k));
        net.b{k} = zeros(dims(k+1), 1);
    end

elseif strcmp(arch_type, 'DuelingDQN')
    % Shared trunk (n_hidden - 1 layers)
    net.n_trunk = max(1, n_hidden - 1);
    trunk_dims  = [state_dim, repmat(hidden_units, 1, net.n_trunk)];
    net.W_trunk = cell(net.n_trunk, 1);
    net.b_trunk = cell(net.n_trunk, 1);
    for k = 1:net.n_trunk
        s = scale(trunk_dims(k), trunk_dims(k+1));
        net.W_trunk{k} = s * randn(trunk_dims(k+1), trunk_dims(k));
        net.b_trunk{k} = zeros(trunk_dims(k+1), 1);
    end
    % Value stream
    s = scale(hidden_units, hidden_units);
    net.W_val  = {s*randn(hidden_units, hidden_units); ...
                  scale(hidden_units,1)*randn(1, hidden_units)};
    net.b_val  = {zeros(hidden_units,1); 0};
    % Advantage stream
    net.W_adv  = {s*randn(hidden_units, hidden_units); ...
                  scale(hidden_units,n_actions)*randn(n_actions, hidden_units)};
    net.b_adv  = {zeros(hidden_units,1); zeros(n_actions,1)};
end
end


function [Q, cache] = qnetwork_forward(net, state)
% QNETWORK_FORWARD  Forward pass through the Q-network.
%
%   [Q, cache] = qnetwork_forward(net, state)
%
%   Inputs:
%     net   - network struct
%     state - [state_dim x 1] or [state_dim x batch] state vector(s)
%
%   Outputs:
%     Q     - [n_actions x batch] Q-values
%     cache - activations for backpropagation
% -------------------------------------------------------------------------

x = state;
cache.inputs = {};

if strcmp(net.arch_type, 'DQN')
    cache.inputs{1} = x;
    for k = 1:length(net.W)-1
        x = net.W{k} * x + net.b{k};
        x = max(0, x);   % ReLU
        cache.inputs{k+1} = x;
    end
    Q = net.W{end} * x + net.b{end};   % linear output

elseif strcmp(net.arch_type, 'DuelingDQN')
    % Shared trunk
    for k = 1:net.n_trunk
        x = net.W_trunk{k} * x + net.b_trunk{k};
        x = max(0, x);
    end
    cache.trunk = x;
    % Value stream
    v = max(0, net.W_val{1} * x + net.b_val{1});
    V = net.W_val{2} * v + net.b_val{2};          % [1 x batch]
    % Advantage stream
    a = max(0, net.W_adv{1} * x + net.b_adv{1});
    A = net.W_adv{2} * a + net.b_adv{2};          % [n_actions x batch]
    % Combine (Eq. 10 in paper)
    Q = V + (A - mean(A, 1));
end
end


function net = qnetwork_update(net, states, actions, targets, lr)
% QNETWORK_UPDATE  One gradient descent step via MSE Bellman loss.
%
%   net = qnetwork_update(net, states, actions, targets, lr)
%
%   Uses finite-difference numerical gradient for pure-MATLAB compatibility.
%   For production use, replace with MATLAB autograd or Deep Learning Toolbox.
%
%   Inputs:
%     states  - [state_dim x batch]  current states
%     actions - [batch x 1]          actions taken (1-indexed internally)
%     targets - [batch x 1]          Bellman target Q-values
%     lr      - learning rate
% -------------------------------------------------------------------------

batch = size(states, 2);
eps_grad = 1e-4;

if strcmp(net.arch_type, 'DQN')
    n_layers = length(net.W);
    for layer = 1:n_layers
        [rows, cols] = size(net.W{layer});
        dW = zeros(rows, cols);
        for i = 1:rows
            for j = 1:cols
                net_p      = net; net_p.W{layer}(i,j) = net.W{layer}(i,j) + eps_grad;
                net_m      = net; net_m.W{layer}(i,j) = net.W{layer}(i,j) - eps_grad;
                loss_p     = bellman_loss(net_p, states, actions, targets);
                loss_m     = bellman_loss(net_m, states, actions, targets);
                dW(i,j)    = (loss_p - loss_m) / (2*eps_grad);
            end
        end
        net.W{layer} = net.W{layer} - lr * dW;
        db = zeros(size(net.b{layer}));
        for i = 1:length(net.b{layer})
            net_p = net; net_p.b{layer}(i) = net.b{layer}(i) + eps_grad;
            net_m = net; net_m.b{layer}(i) = net.b{layer}(i) - eps_grad;
            db(i) = (bellman_loss(net_p,states,actions,targets) - ...
                     bellman_loss(net_m,states,actions,targets)) / (2*eps_grad);
        end
        net.b{layer} = net.b{layer} - lr * db;
    end
end
% Note: Dueling DQN update follows the same pattern applied to
% W_trunk, W_val, W_adv, b_trunk, b_val, b_adv.
end


function loss = bellman_loss(net, states, actions, targets)
% BELLMAN_LOSS  Mean squared Bellman error.
% -------------------------------------------------------------------------

Q   = qnetwork_forward(net, states);        % [n_actions x batch]
batch = size(states, 2);
loss = 0;
for i = 1:batch
    a_i   = actions(i) + 1;                 % 0-indexed to 1-indexed
    loss  = loss + (Q(a_i, i) - targets(i))^2;
end
loss = loss / batch;
end


function net_target = qnetwork_sync(net_online, net_target)
% QNETWORK_SYNC  Hard-copy online weights to target network.
%
%   Called every cfg.target_sync training steps to stabilise learning.
% -------------------------------------------------------------------------

net_target = net_online;
end
