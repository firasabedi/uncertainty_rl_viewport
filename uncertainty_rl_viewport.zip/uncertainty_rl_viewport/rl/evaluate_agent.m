function results = evaluate_agent(agent, positions_test, server_test, cfg)
% EVALUATE_AGENT  Evaluate a trained agent on the test set.
%
%   results = evaluate_agent(agent, positions_test, server_test, cfg)
%
%   Inputs:
%     agent          - trained agent struct from train_agent()
%     positions_test - [N_test x 3] test head-position sequence
%     server_test    - server predictor struct for test set
%     cfg            - configuration struct
%
%   Outputs:
%     results struct with fields:
%       .mse_rl        - scalar, RL agent MSE
%       .mse_sml       - scalar, S-ML (local-only) MSE
%       .mse_lml       - scalar, L-ML (always-offload) MSE
%       .mse_cpo       - scalar, CPO (random offloading) MSE
%       .mse_genie     - scalar, Genie oracle MSE
%       .gain_rl       - scalar, normalized gain (Eq. 11)
%       .offload_rate  - scalar, realized offloading rate (should ~ zeta)
%       .mse_per_task  - [N_test x 1] per-task MSE of RL agent
%       .offload_decisions - [N_test x 1] binary offloading decisions
% -------------------------------------------------------------------------

N_test = size(positions_test, 1);
H      = cfg.H;
zeta   = cfg.zeta;

%% ---- Pre-compute baselines ----------------------------------------
[mse_sml, sml_errors] = baseline_sml(positions_test, cfg);
[mse_lml, lml_errors] = baseline_lml(positions_test, server_test);
[mse_cpo, cpo_errors] = baseline_cpo(positions_test, server_test, cfg);
[mse_genie, genie_errors] = baseline_genie(positions_test, server_test, cfg);

%% ---- Run RL agent in greedy mode ----------------------------------
lms         = lms_predictor_init(H, cfg.lms_mu, cfg.lms_n_axes);
C_n         = 0;
mse_per_task   = zeros(N_test-1, 1);
offload_dec    = zeros(N_test-1, 1);
total_offloads = 0;

% Warm-up LMS
for t = 1:min(H, N_test)
    [~, lms] = lms_predict(lms, positions_test(t,:));
end

for t = H+1 : N_test-1
    p_current = positions_test(t,   :);
    p_next    = positions_test(t+1, :);

    [p_hat_local, lms] = lms_predict(lms, p_current);
    s_n = build_state(lms, p_hat_local, C_n, agent.state_type, cfg);

    % Greedy action (no exploration)
    [Q_vals, ~] = qnetwork_forward(agent.net_online, s_n);
    [~, a_idx]  = max(Q_vals);
    a_n         = a_idx - 1;

    step_n  = t - H;
    C_n     = update_offloading_rate(C_n, a_n, step_n);
    offload_dec(step_n) = a_n;
    total_offloads = total_offloads + a_n;

    if a_n == 1
        p_hat_final = get_server_prediction(server_test, t);
    else
        p_hat_final = p_hat_local;
    end

    mse_per_task(step_n) = sum((p_next - p_hat_final).^2);
end

n_eval = N_test - 1 - H;

%% ---- Pack results -------------------------------------------------
results.mse_rl        = mean(mse_per_task(1:n_eval));
results.mse_sml       = mse_sml;
results.mse_lml       = mse_lml;
results.mse_cpo       = mse_cpo;
results.mse_genie     = mse_genie;
results.mse_per_task  = mse_per_task(1:n_eval);
results.offload_decisions = offload_dec(1:n_eval);
results.offload_rate  = total_offloads / n_eval;
results.sml_errors    = sml_errors;
results.lml_errors    = lml_errors;

% Normalized gain (Eq. 11)
denom = results.mse_genie - results.mse_cpo;
if abs(denom) < 1e-10
    results.gain_rl = NaN;
else
    results.gain_rl = 100 * (results.mse_rl - results.mse_cpo) / denom;
end

fprintf('[Eval] MSE_RL=%.5f | Gain=%.1f%% | OR=%.3f (target=%.2f)\n', ...
    results.mse_rl, results.gain_rl, results.offload_rate, cfg.zeta);
end


% =========================================================================
%  BASELINE FUNCTIONS
% =========================================================================

function [mse, errors] = baseline_sml(positions, cfg)
% S-ML: local LMS predictor only (no offloading).

H   = cfg.H;
N   = size(positions, 1);
lms = lms_predictor_init(H, cfg.lms_mu, cfg.lms_n_axes);
errors = zeros(N-1, 1);

for t = 1:N-1
    [p_hat, lms] = lms_predict(lms, positions(t,:));
    if t > H
        errors(t) = sum((positions(t+1,:) - p_hat).^2);
    end
end
valid = errors(H+1:end);
mse   = mean(valid);
end


function [mse, errors] = baseline_lml(positions, server)
% L-ML: always offload to server (upper bound, no constraint).

N      = size(positions, 1);
errors = zeros(N-1, 1);
for t = 1:N-1
    p_server  = get_server_prediction(server, t);
    errors(t) = sum((positions(t+1,:) - p_server).^2);
end
mse = mean(errors);
end


function [mse, errors] = baseline_cpo(positions, server, cfg)
% CPO: random offloading with probability zeta (no intelligence).

H      = cfg.H;
N      = size(positions, 1);
lms    = lms_predictor_init(H, cfg.lms_mu, cfg.lms_n_axes);
errors = zeros(N-1, 1);

for t = 1:N-1
    [p_hat_local, lms] = lms_predict(lms, positions(t,:));
    if rand() < cfg.zeta
        p_hat = get_server_prediction(server, t);
    else
        p_hat = p_hat_local;
    end
    errors(t) = sum((positions(t+1,:) - p_hat).^2);
end
mse = mean(errors(H+1:end));
end


function [mse, errors] = baseline_genie(positions, server, cfg)
% Genie: oracle that offloads exactly the zeta fraction of tasks with
% the LARGEST local prediction error.

H   = cfg.H;
N   = size(positions, 1);
lms = lms_predictor_init(H, cfg.lms_mu, cfg.lms_n_axes);

local_errors = zeros(N-1, 1);
local_preds  = zeros(N-1, 3);

for t = 1:N-1
    [p_hat, lms]     = lms_predict(lms, positions(t,:));
    local_preds(t,:) = p_hat;
    local_errors(t)  = sum((positions(t+1,:) - p_hat).^2);
end

% Select top-zeta fraction for offloading
n_offload = round(cfg.zeta * (N-1));
[~, sorted_idx] = sort(local_errors, 'descend');
offload_mask = false(N-1, 1);
offload_mask(sorted_idx(1:n_offload)) = true;

errors = zeros(N-1, 1);
for t = 1:N-1
    if offload_mask(t)
        p_hat = get_server_prediction(server, t);
    else
        p_hat = local_preds(t,:);
    end
    errors(t) = sum((positions(t+1,:) - p_hat).^2);
end
mse = mean(errors(H+1:end));
end
