function [agent, episode_rewards, offload_rates] = train_agent( ...
    positions, server, cfg, agent_type, state_type, seed)
% TRAIN_AGENT  Train a single DQN/Dueling DQN offloading agent.
%
%   [agent, episode_rewards, offload_rates] = ...
%       train_agent(positions, server, cfg, agent_type, state_type, seed)
%
%   Implements Algorithm 1 from the paper:
%     1. For each episode, iterate through training trajectory
%     2. Compute LMS prediction + variance proxy
%     3. Construct state vector
%     4. Select action via epsilon-greedy
%     5. Execute action (local or server prediction)
%     6. Compute reward
%     7. Store transition; sample mini-batch; update Q-network
%     8. Periodically sync target network
%
%   Inputs:
%     positions  - [N x 3] head-position sequence (training split)
%     server     - server predictor struct
%     cfg        - configuration struct
%     agent_type - 'DQN' | 'DuelingDQN'
%     state_type - 'L2'  | 'Pos'
%     seed       - integer random seed
%
%   Outputs:
%     agent          - trained agent struct (online Q-network + metadata)
%     episode_rewards - [n_episodes x 1] total reward per episode
%     offload_rates   - [n_episodes x 1] mean offloading rate per episode
% -------------------------------------------------------------------------

rng(seed, 'twister');

N_train = size(positions, 1);
H       = cfg.H;

%% ---- Determine state dimension ------------------------------------
if strcmp(state_type, 'L2')
    state_dim = cfg.state_dim_L2;
else
    state_dim = cfg.state_dim_Pos;
end

%% ---- Initialise components ----------------------------------------
net_online = qnetwork_init(state_dim, cfg.n_actions, ...
    cfg.n_hidden_layers, cfg.hidden_units, agent_type);
net_target = net_online;   % target network starts identical
buf        = replay_buffer_init(cfg.buffer_size, state_dim);

episode_rewards = zeros(cfg.n_episodes, 1);
offload_rates   = zeros(cfg.n_episodes, 1);

eps         = cfg.eps_start;
global_step = 0;

%% ---- Training loop ------------------------------------------------
for ep = 1:cfg.n_episodes

    % Reset episode state
    lms = lms_predictor_init(H, cfg.lms_mu, cfg.lms_n_axes);
    C_n = 0;   % offloading rate counter
    ep_reward   = 0;
    ep_offloads = 0;

    % Warm-up LMS buffer with first H observations
    for t = 1:H
        if t <= N_train
            [~, lms] = lms_predict(lms, positions(t,:));
        end
    end

    % Episode trajectory (sample random start for variety)
    t_start = max(H+1, randi(max(1, N_train - 500)));
    t_end   = min(N_train - 1, t_start + 500);

    for t = t_start : t_end
        p_current = positions(t,   :);
        p_next    = positions(t+1, :);

        % 1. Local prediction
        [p_hat_local, lms] = lms_predict(lms, p_current);

        % 2. Build state
        s_n = build_state(lms, p_hat_local, C_n, state_type, cfg);

        % 3. Epsilon-greedy action selection
        if rand() < eps
            a_n = randi([0, 1]) - 1;   % random: 0 or 1
        else
            [Q_vals, ~] = qnetwork_forward(net_online, s_n);
            [~, a_idx] = max(Q_vals);
            a_n = a_idx - 1;           % back to 0-indexed
        end

        % 4. Execute action
        step_n = t - t_start + 1;
        C_n    = update_offloading_rate(C_n, a_n, step_n);
        if a_n == 1
            p_hat_final = get_server_prediction(server, t);
            ep_offloads = ep_offloads + 1;
        else
            p_hat_final = p_hat_local;
        end

        % 5. Compute reward
        [R_n, ~] = compute_reward(p_next, p_hat_final, C_n, cfg);
        ep_reward = ep_reward + R_n;

        % 6. Next state
        [p_hat_next, lms_next] = lms_predict(lms, p_next);
        C_next = update_offloading_rate(C_n, 0, step_n+1);
        s_next = build_state(lms_next, p_hat_next, C_next, state_type, cfg);
        done   = (t == t_end);

        % 7. Store transition
        buf = replay_buffer_add(buf, s_n, a_n, R_n, s_next, done);

        % 8. Mini-batch update
        global_step = global_step + 1;
        if buf.size >= cfg.batch_size
            [s_b, a_b, r_b, s_nb, done_b] = ...
                replay_buffer_sample(buf, cfg.batch_size);

            % Compute Bellman targets
            targets = zeros(cfg.batch_size, 1);
            for bi = 1:cfg.batch_size
                if done_b(bi)
                    targets(bi) = r_b(bi);
                else
                    [Q_next, ~] = qnetwork_forward(net_target, s_nb(bi,:)');
                    targets(bi) = r_b(bi) + cfg.gamma * max(Q_next);
                end
            end

            % Update online network
            net_online = qnetwork_update(net_online, s_b', a_b, targets, cfg.lr);

            % Sync target network periodically
            if mod(global_step, cfg.target_sync) == 0
                net_target = qnetwork_sync(net_online, net_target);
            end
        end
    end   % end epoch loop

    % Decay epsilon
    eps = max(cfg.eps_min, eps * cfg.eps_decay);

    ep_len = t_end - t_start + 1;
    episode_rewards(ep) = ep_reward / ep_len;
    offload_rates(ep)   = ep_offloads / ep_len;

    if cfg.verbose && mod(ep, 50) == 0
        fprintf('  [%s-%s seed=%d] Ep %3d/%d | Reward=%.3f | eps=%.3f | OR=%.3f\n', ...
            agent_type, state_type, seed, ep, cfg.n_episodes, ...
            episode_rewards(ep), eps, offload_rates(ep));
    end
end   % end episode loop

%% ---- Pack trained agent -------------------------------------------
agent.net_online  = net_online;
agent.net_target  = net_target;
agent.agent_type  = agent_type;
agent.state_type  = state_type;
agent.state_dim   = state_dim;
agent.seed        = seed;
agent.cfg         = cfg;
end
