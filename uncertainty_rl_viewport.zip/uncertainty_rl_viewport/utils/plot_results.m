function plot_offloading_vs_error(results, cfg)
% PLOT_OFFLOADING_VS_ERROR  Reproduce Figure 7 (histogram of offloading decisions).
%
%   plot_offloading_vs_error(results, cfg)
%
%   Inputs:
%     results - output struct from evaluate_agent()
%     cfg     - configuration struct
% -------------------------------------------------------------------------

errors_all   = results.sml_errors;
decisions    = results.offload_decisions;

N_eval = min(length(errors_all), length(decisions));
err    = errors_all(1:N_eval);
dec    = decisions(1:N_eval);

err_local    = err(dec == 0);
err_offloaded = err(dec == 1);

fig = figure('Visible','off','Position',[0 0 600 400]);
hold on;
bin_edges = linspace(0, max(err)*1.05, 40);

histogram(err_local,    bin_edges, 'FaceColor','#4472C4', ...
          'FaceAlpha',0.6, 'DisplayName','Local Execution');
histogram(err_offloaded, bin_edges, 'FaceColor','#ED7D31', ...
          'FaceAlpha',0.6, 'DisplayName','Offloaded to Server');

xlabel('S-ML Prediction Error'); ylabel('Number of Tasks');
legend('Location','northeast'); grid on;
title('Offloading Decisions vs. Local Prediction Error');

% Mann-Whitney U test
[U, p_val, r_eff] = mann_whitney_u(err_local, err_offloaded);
annotation('textbox',[0.55,0.70,0.35,0.15],'String', ...
    sprintf('Mann-Whitney U=%.0f\np=%.2e, r=%.2f', U, p_val, r_eff), ...
    'EdgeColor','k','BackgroundColor','w','FontSize',8);

save_figure(fig, 'Fig7_offloading_vs_error', cfg);
end


function plot_testing_error(mse_rl, mse_cpo, mse_sml, mse_lml, mse_genie, ...
                             offload_rate_vec, zeta, cfg, fig_tag)
% PLOT_TESTING_ERROR  Reproduce Figures 6 and 9 (temporal MSE + offloading rate).

N   = length(mse_rl);
fig = figure('Visible','off','Position',[0 0 800 600]);

subplot(2,1,1); hold on; grid on;
plot(1:N, mse_rl,    'b',  'LineWidth',1.2, 'DisplayName','RL');
plot(1:N, mse_cpo,   'r',  'LineWidth',1.0, 'DisplayName','CPO');
plot(1:N, mse_sml,   'g',  'LineWidth',1.0, 'DisplayName','S-ML');
plot(1:N, mse_lml,   'm',  'LineWidth',1.0, 'DisplayName','L-ML');
plot(1:N, mse_genie, 'k',  'LineWidth',1.0, 'DisplayName','Genie');
ylabel('MSE'); legend('Location','northeast','FontSize',8);
title('Test Performance: MSE Comparison');

subplot(2,1,2); hold on; grid on;
plot(1:N, offload_rate_vec, 'b', 'LineWidth',1.5, 'DisplayName','RL Offloading Rate');
yline(zeta,          'r--', 'LineWidth',1.5, 'DisplayName','Target Constraint');
yline(zeta + 0.05,   'k:',  'LineWidth',1.0, 'DisplayName','Upper Tolerance');
yline(max(0,zeta-0.05), 'k:','LineWidth',1.0, 'DisplayName','Lower Tolerance');
ylabel('Offloading Rate'); xlabel('Tasks');
legend('Location','northeast','FontSize',8);
title('Offloading Rate vs. Constraint');

save_figure(fig, fig_tag, cfg);
end


function plot_training_convergence(episode_rewards_all, labels, fig_tag, cfg)
% PLOT_TRAINING_CONVERGENCE  Plot mean reward curves for all agent configs.

fig = figure('Visible','off','Position',[0 0 700 400]);
hold on; grid on;
colors = {'b','c','r','m','g','k'};
for k = 1:size(episode_rewards_all, 1)
    plot(episode_rewards_all(k,:), colors{mod(k-1,length(colors))+1}, ...
        'LineWidth',1.5, 'DisplayName', labels{k});
end
xlabel('Training Episodes'); ylabel('Average Total Reward');
legend('Location','northwest','FontSize',9);
save_figure(fig, fig_tag, cfg);
end


function plot_sensitivity_H(H_grid, mse_means, ci_lo, ci_hi, cfg)
% PLOT_SENSITIVITY_H  Bar chart of MSE vs history length H.

fig = figure('Visible','off','Position',[0 0 500 350]);
hold on; grid on;
errorbar(H_grid, mse_means, mse_means-ci_lo, ci_hi-mse_means, ...
    'b-o', 'LineWidth',1.5, 'MarkerSize',8, 'MarkerFaceColor','b');
xline(5, 'r--', 'H=5 (selected)', 'LineWidth',1.5);
xlabel('History Length H'); ylabel('MSE');
title('Sensitivity to History Length H');
xticks(H_grid);
save_figure(fig, 'FigS_sensitivity_H', cfg);
end


function plot_extended_metrics(all_metrics, dataset_names, cfg)
% PLOT_EXTENDED_METRICS  Grouped bar chart of WI, SS, APB, EVS.

metrics = {'wi','ss','apb','evs'};
labels  = {'WI (↑)','SS (↑)','APB% (↓)','EVS (↑)'};
n_d     = length(dataset_names);
vals    = zeros(n_d, 4);

for d = 1:n_d
    m = all_metrics{d};
    vals(d,:) = [m.wi, m.ss, m.apb/100, m.evs];
end

fig = figure('Visible','off','Position',[0 0 700 350]);
b = bar(vals, 'grouped');
set(gca,'XTickLabel', strrep(dataset_names,'_',' '));
legend(labels, 'Location','southeast','FontSize',8);
ylabel('Metric Value'); title('Extended Evaluation Metrics (Dueling DQN L2)');
ylim([0 1.1]);
save_figure(fig, 'FigS_extended_metrics', cfg);
end
