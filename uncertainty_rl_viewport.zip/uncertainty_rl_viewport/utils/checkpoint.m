function save_agent(agent, episode_rewards, offload_rates, fname, cfg)
% SAVE_AGENT  Save a trained agent and its training curves to disk.
%
%   save_agent(agent, episode_rewards, offload_rates, fname, cfg)
%
%   Inputs:
%     agent           - trained agent struct
%     episode_rewards - [n_episodes x 1] reward history
%     offload_rates   - [n_episodes x 1] offloading rate history
%     fname           - output filename (without extension)
%     cfg             - configuration struct
%
%   Saves to:  results/logs/<fname>_seed<N>.mat
% -------------------------------------------------------------------------

out_dir = cfg.log_dir;
if ~exist(out_dir, 'dir'), mkdir(out_dir); end

out_path = fullfile(out_dir, sprintf('%s_seed%d.mat', fname, agent.seed));
save(out_path, 'agent', 'episode_rewards', 'offload_rates', '-v7.3');
fprintf('[Save] Agent saved: %s\n', out_path);
end


function [agent, episode_rewards, offload_rates] = load_agent(fname, seed, cfg)
% LOAD_AGENT  Load a previously saved agent from disk.
%
%   [agent, episode_rewards, offload_rates] = load_agent(fname, seed, cfg)
%
%   Inputs:
%     fname - base filename (without _seed<N>.mat suffix)
%     seed  - seed number to load
%     cfg   - configuration struct
%
%   Throws an error if the file does not exist.
% -------------------------------------------------------------------------

fpath = fullfile(cfg.log_dir, sprintf('%s_seed%d.mat', fname, seed));
if ~exist(fpath, 'file')
    error('[Load] Agent file not found: %s\nRun training first.', fpath);
end
S = load(fpath, 'agent', 'episode_rewards', 'offload_rates');
agent          = S.agent;
episode_rewards = S.episode_rewards;
offload_rates   = S.offload_rates;
fprintf('[Load] Agent loaded: %s\n', fpath);
end


function save_results_table(results_struct, fname, cfg)
% SAVE_RESULTS_TABLE  Export a results struct to a CSV summary file.
%
%   save_results_table(results_struct, fname, cfg)
% -------------------------------------------------------------------------

out_dir  = cfg.log_dir;
if ~exist(out_dir, 'dir'), mkdir(out_dir); end
out_path = fullfile(out_dir, [fname, '.csv']);

fields = fieldnames(results_struct);
fid    = fopen(out_path, 'w');
fprintf(fid, '%s\n', strjoin(fields, ','));
vals = cellfun(@(f) results_struct.(f), fields, 'UniformOutput', false);
fmt  = repmat('%g,', 1, length(fields));
fmt  = [fmt(1:end-1), '\n'];
fprintf(fid, fmt, cell2mat(vals));
fclose(fid);
fprintf('[Save] Results CSV saved: %s\n', out_path);
end
