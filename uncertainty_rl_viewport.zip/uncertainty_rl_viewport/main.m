% =========================================================================
% MAIN.M — Master Entry Point
% =========================================================================
% Uncertainty-Aware Reinforcement Learning for Hierarchical Viewport
% Prediction Under Offloading Constraints
%
% Paper: AJSE-D-26-01259, Arabian Journal for Science and Engineering
% Authors: L.F.M.H. Al-Rammahi, H.A. Mohammed, M.A.N. Shukur, F. Abedi
% Affiliation: Najaf Technical Institute, Al-Furat Al-Awsat Technical
%              University, Iraq
%
% USAGE:
%   Run this script from the project root directory:
%       >> main
%
%   Or run individual experiments:
%       >> run_experiment('training')   % convergence curves
%       >> run_experiment('ablation')   % proxy ablation study
%       >> run_experiment('all')        % reproduce all paper results
%
% REQUIREMENTS:
%   - MATLAB R2020b or later
%   - Deep Learning Toolbox (for dlarray operations, optional)
%   - Statistics and Machine Learning Toolbox (for ranksum/wilcoxon)
%   - Datasets placed in  data/raw/  (see data/README_datasets.md)
%
% OUTPUTS:
%   All figures saved to  results/figures/
%   All logs  saved to  results/logs/
% =========================================================================

clear; clc; close all;
rng(42, 'twister');   % global seed for reproducibility

%% ---- 0. Add all sub-folders to path --------------------------------
project_root = fileparts(mfilename('fullpath'));
addpath(genpath(project_root));
fprintf('=======================================================\n');
fprintf('  Uncertainty-Aware RL for Viewport Prediction\n');
fprintf('  Project root: %s\n', project_root);
fprintf('=======================================================\n\n');

%% ---- 1. Load configuration -----------------------------------------
cfg = get_config();
fprintf('[Config] History length H=%d | Budget zeta=%.2f | Lambda=%.2f\n', ...
    cfg.H, cfg.zeta, cfg.lambda);

%% ---- 2. Select experiment ------------------------------------------
fprintf('\nAvailable experiments:\n');
fprintf('  1. Training convergence (clean + noisy)\n');
fprintf('  2. Ablation study (reliability proxy variants)\n');
fprintf('  3. Sensitivity: history length H\n');
fprintf('  4. Sensitivity: hyperparameters (gamma, zeta, lambda)\n');
fprintf('  5. In-distribution results (David_MMSys)\n');
fprintf('  6. Cross-dataset generalization\n');
fprintf('  7. Multi-step prediction + reward shaping\n');
fprintf('  8. Robustness to degraded local predictor\n');
fprintf('  9. Latency sensitivity\n');
fprintf('  10. All experiments (reproduces all paper tables/figures)\n');

choice = input('\nSelect experiment [1-10]: ');
if isempty(choice), choice = 10; end

run_experiment(choice, cfg);
