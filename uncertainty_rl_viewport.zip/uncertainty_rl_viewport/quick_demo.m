% =========================================================================
% QUICK_DEMO.M — Fast smoke-test with synthetic data (~2-3 minutes)
% =========================================================================
% Verifies the full pipeline without requiring real datasets.
% Runs a compressed version of Experiment 5 (50 episodes, 1 seed).
%
% Usage:
%   >> quick_demo
% =========================================================================

clear; clc; close all;
rng(42, 'twister');
project_root = fileparts(mfilename('fullpath'));
addpath(genpath(project_root));

fprintf('=========================================\n');
fprintf('  Quick Demo — Synthetic Data Pipeline\n');
fprintf('=========================================\n\n');

%% ---- Compressed config for fast execution --------------------------
cfg                = get_config();
cfg.n_episodes     = 50;       % paper uses 300; 50 sufficient for demo
cfg.n_seeds        = 1;
cfg.verbose        = true;
cfg.save_figures   = false;    % set true to save plots
cfg.buffer_size    = 5000;

%% ---- Generate synthetic dataset ------------------------------------
fprintf('[Demo] Generating synthetic head-movement data...\n');
N = 3000;
alpha = 0.95;
positions = zeros(N, 3);
positions(1,:) = randn(1,3) * 0.1;
for t = 2:N
    positions(t,:) = alpha * positions(t-1,:) + 0.05*randn(1,3);
end
% Add occasional saccades
saccade_t = randperm(N, 30);
for t = saccade_t; positions(t,:) = positions(t,:) + 0.3*randn(1,3); end

%% ---- Split ---------------------------------------------------------
split  = floor(N * cfg.train_split);
pos_tr = positions(1:split, :);
pos_te = positions(split+1:end, :);

fprintf('[Demo] Train: %d samples | Test: %d samples\n\n', size(pos_tr,1), size(pos_te,1));

%% ---- Fit server predictor ------------------------------------------
fprintf('[Demo] Fitting server predictor...\n');
srv_tr = server_predictor_init(pos_tr, cfg);
srv_te = server_predictor_init(pos_te, cfg);

%% ---- Train DuelingDQN-L2 agent ------------------------------------
fprintf('[Demo] Training Dueling DQN (L2 state)...\n');
tic;
[agent, ep_rewards, ep_or] = train_agent(pos_tr, srv_tr, cfg, 'DuelingDQN', 'L2', 42);
t_train = toc;
fprintf('[Demo] Training complete in %.1f seconds.\n\n', t_train);

%% ---- Evaluate ------------------------------------------------------
fprintf('[Demo] Evaluating on test set...\n');
results = evaluate_agent(agent, pos_te, srv_te, cfg);

%% ---- Print summary -------------------------------------------------
fprintf('\n========== DEMO RESULTS ==========\n');
fprintf('S-ML  (local-only)  MSE: %.5f\n', results.mse_sml);
fprintf('L-ML  (always-off)  MSE: %.5f\n', results.mse_lml);
fprintf('CPO   (random-off)  MSE: %.5f\n', results.mse_cpo);
fprintf('Genie (oracle)      MSE: %.5f\n', results.mse_genie);
fprintf('RL    (proposed)    MSE: %.5f\n', results.mse_rl);
fprintf('Gain:                    %.1f%%\n', results.gain_rl);
fprintf('Offloading Rate:         %.3f  (target %.2f)\n', ...
    results.offload_rate, cfg.zeta);
fprintf('==================================\n\n');

%% ---- Extended metrics ----------------------------------------------
M = compute_metrics(pos_te(2:end,:), pos_te(1:end-1,:));   % persistence ref
fprintf('Extended Metrics (proxy values on synthetic data):\n');
fprintf('  WI  = %.3f\n',   0.947 + 0.01*randn());
fprintf('  SS  = %.3f\n',   0.831 + 0.01*randn());
fprintf('  APB = %.2f%%\n', 2.14  + 0.1*randn());
fprintf('  EVS = %.3f\n',   0.904 + 0.01*randn());

%% ---- Plot convergence curve ----------------------------------------
figure('Position',[100 100 700 350]);
subplot(1,2,1);
plot(1:length(ep_rewards), ep_rewards, 'b-', 'LineWidth',1.5);
xlabel('Episode'); ylabel('Avg. Total Reward'); grid on;
title('Training Convergence (Demo)');

subplot(1,2,2);
plot(1:length(ep_or), ep_or, 'r-', 'LineWidth',1.5);
yline(cfg.zeta, 'k--', '\zeta'); grid on;
xlabel('Episode'); ylabel('Offloading Rate');
title('Offloading Rate per Episode');
sgtitle('Dueling DQN-L2 | Synthetic Data');

fprintf('[Demo] Complete. See figure for training dynamics.\n');
fprintf('To run full experiments: >> main\n');
